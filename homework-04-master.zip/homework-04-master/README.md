homework-04
===========

the 4th homework for my software lesson


requirments
===========
*  ruby 1.8.7



usage
===========
*  run homework04.rb such as`$ ruby homework04.rb allwords.txt 18x18`
*  the last parameter set the target size of the matrix, you can try change it by yourself to find the minimum matrix.
*  you can find the puzzle by checking the search.txt.
*  you can find the solution of the generated matrix by checking the solution.txt.
*  I have added comments on the necessary place.

License
===========
Based on [WTFPL](http://en.wikipedia.org/wiki/WTFPL).
